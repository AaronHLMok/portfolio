function myShader(gl, shaderSource, shaderType){


}